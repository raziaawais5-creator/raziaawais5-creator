import pandas as pd
df = pd.read_csv('../Data/Cybercrime_Uncleaned_Dataset.csv')
df['Region'] = df['Region'].fillna('Unknown')
df['Crime_Type'] = df['Crime_Type'].fillna('Unknown')
df['Severity'] = df['Severity'].fillna('Low')
df = df.drop_duplicates(subset=['Crime_ID'])
print(df.head())
