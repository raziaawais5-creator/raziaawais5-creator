# Cybercrime EDA Script
import pandas as pd
df = pd.read_csv('../Cybercrime_Cleaned_Dataset.csv')
print(df.head())
print(df.describe())
print(df['Crime_Type'].value_counts())

# Run the Python script directly
