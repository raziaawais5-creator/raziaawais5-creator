import pandas as pd
df = pd.read_csv('../Data/Cybercrime_Cleaned_Dataset.csv')
print(df['Crime_Type'].value_counts())
monthly = df.groupby(['Year','Month']).size().reset_index(name='Crime_Count')
print(monthly.head())
