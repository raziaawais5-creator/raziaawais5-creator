# Cybercrime Time Allocation and Critical Path
import pandas as pd
df = pd.read_csv('../Cybercrime_Cleaned_Dataset.csv')
monthly_trends = df.groupby(['Year', 'Month']).size().reset_index(name='Crime_Count')
print(monthly_trends)
