import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv('../Data/Cybercrime_Cleaned_Dataset.csv')
monthly = df.groupby(['Year','Month']).size().reset_index(name='Crime_Count')
monthly['Date'] = pd.to_datetime(monthly['Year'].astype(str) + '-' + monthly['Month'].astype(str))
monthly.set_index('Date', inplace=True)
model = ARIMA(monthly['Crime_Count'], order=(1,1,1))
model_fit = model.fit()
forecast = model_fit.forecast(steps=3)
print(forecast)
