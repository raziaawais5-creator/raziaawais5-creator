# Cybercrime Analysis Project

## Overview
This project analyzes cybercrime trends across US regions. It includes raw, cleaned, and merged datasets, along with Python scripts for data cleaning, EDA, and predictive analysis.

## Data
- `Data/Cybercrime_Uncleaned_Dataset.csv`
- `Data/Cybercrime_Cleaned_Dataset.csv`
- `Data/Cybercrime_Merged_Dataset.csv`

## Scripts
- `Scripts_Notebooks/1_Data_Cleaning.py`
- `Scripts_Notebooks/2_EDA.py`
- `Scripts_Notebooks/3_Predictive_Analysis.py`

## Folder Structure
Cybercrime_Project/
├─ Data/
├─ Scripts_Notebooks/
├─ Dashboards/  # placeholder
└─ README.md

## Workflow
1. Inspect and clean raw data
2. Perform EDA
3. Apply predictive models
4. Generate insights

## Future Improvements
- Add interactive dashboards
- Enhance predictive modeling
- Automate data collection via APIs
